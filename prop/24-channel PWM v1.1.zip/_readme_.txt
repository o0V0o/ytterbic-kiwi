Project : 24-channel PWM LED driver with 8 bits of intensity per channel
Author  : Alex Hajnal (AKH)
Version : 1.1
Date    : 2014-03-30

PWM routines.spin
  │
  ├──24-channel PWM.spin
  │
  ├──PWM demo.spin
  │    │
  │    └──24-channel PWM.spin
  │
  └──I2C PWM.spin
       │
       ├──24-channel PWM.spin
       │
       └──I2C slave v1.0a.spin


